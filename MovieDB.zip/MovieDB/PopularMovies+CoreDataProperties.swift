//
//  PopularMovies+CoreDataProperties.swift
//  MovieDB
//
//  Created by Mahendran on 01/05/21.
//  Copyright © 2021 mahendran. All rights reserved.
//
//

import Foundation
import CoreData


extension PopularMovies {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<PopularMovies> {
        return NSFetchRequest<PopularMovies>(entityName: "PopularMovies")
    }

    @NSManaged public var popularId: String?
    @NSManaged public var popularRating: Float
    @NSManaged public var popularImg: String?
    @NSManaged public var popularOverview: String?
    @NSManaged public var popularPoston: String?
    @NSManaged public var popularTitle: String?

}

extension PopularMovies : Identifiable {

}
