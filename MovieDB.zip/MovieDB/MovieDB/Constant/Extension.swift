//
//  Extension.swift
//  MovieDB
//
//  Created by Mahendran on 01/05/21.
//  Copyright © 2021 mahendran. All rights reserved.
//


import UIKit

let screen_width =  UIScreen.main.bounds.size.width
let screen_height =  UIScreen.main.bounds.size.height


//MARK:- EditableLayout.....
class EditableLayoutConstains: NSLayoutConstraint {
    override func awakeFromNib() {
        super.awakeFromNib()
        self.constant = self.constant.autoExpand
    }
}

extension CGFloat
{
    var autoExpand : CGFloat
    {
        return self * (screen_width / 320)
    }
}


extension UIViewController {
    
    // MARK:- Display Alert
    func displayAlertMaessage(userMessage : String)
    {
        let alert = UIAlertController(title: "MovieDB", message: userMessage, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(ok)
        self.present(alert, animated: true, completion: nil)
        
    }
}

// MARK:- ActivityIndicatorView...
public class LoadingView {

    var overlayView : UIView!
    var activityIndicator : UIActivityIndicatorView!

    class var shared: LoadingView {
        struct Static {
            static let instance: LoadingView = LoadingView()
        }
        return Static.instance
    }

    init(){
        self.overlayView = UIView()
        self.activityIndicator = UIActivityIndicatorView()

        overlayView.frame = CGRect(x: 0, y: 0, width: 60, height: 60)
        overlayView.backgroundColor = UIColor.lightGray
        overlayView.clipsToBounds = true
        overlayView.layer.cornerRadius = 10
       

        activityIndicator.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        activityIndicator.center = CGPoint(x: overlayView.bounds.width / 2, y: overlayView.bounds.height / 2)
        activityIndicator.style = .large
        activityIndicator.color = .white
        overlayView.addSubview(activityIndicator)
    }

    public func showOverlay(view: UIView) {
        overlayView.center = view.center
        view.addSubview(overlayView)
        activityIndicator.startAnimating()
    }

    public func hideOverlayView() {
        activityIndicator.stopAnimating()
        overlayView.removeFromSuperview()
    }
}




