//
//  HomeVC.swift
//  MovieDB
//
//  Created by Mahendran on 01/05/21.
//  Copyright © 2021 mahendran. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class HomeVC: UIViewController,  UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource, UIPopoverPresentationControllerDelegate {
    
    @IBOutlet weak var TrendingMovieCollVW: UICollectionView!
    
    
    @IBOutlet weak var PopularMovieTblVW: UITableView!

    var selectIndex : Int?

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.isNavigationBarHidden = true
    
        self.GetTrendingMovies()
        // Do any additional setup after loading the view.
    }
    

    
   // MARK:- CollectionView Follow...
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return TrendingMovieDatas.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let Cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TrendingMovieCollVwCell", for: indexPath) as! TrendingMovieCollVwCell
        let object = TrendingMovieDatas[indexPath.row]
        
        Cell.lblTittle.text! =  (object as AnyObject).value(forKey: "trendTitle") as! String
        
        Cell.lblPostOnDate.text! = "Released on:  " + "\((object as AnyObject).value(forKey: "trendPoston") as! String)"
        
        Cell.lblRate.text! = "Rating:  " + "\(String((object as AnyObject).value(forKey: "trendRating") as! Float))"
        

        if let postImg = (object as AnyObject).value(forKey: "trendImg")  {
            Cell.imgMovie.sd_setShowActivityIndicatorView(true)
            Cell.imgMovie.sd_setIndicatorStyle(.medium)
            
            
            //"https://image.tmdb.org/t/p" + "\(postImg)"
            
            Cell.imgMovie.sd_setImage(with: URL(string: "https://images.unsplash.com/photo-1496065187959-7f07b8353c55?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=750&q=8", relativeTo: nil))
            
        }else {
            Cell.imgMovie.image = UIImage(named: "samplePoster")
            
        }
        return Cell
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
     
     
   
        let size = CGSize(width: self.TrendingMovieCollVW.frame.width  , height: 180)

           
           return size
       
       }
    
    
    // MARK:- TableView Follow...
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PopularMovieDatas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let Cell = tableView.dequeueReusableCell(withIdentifier: "PopularMoviesTblVwCell") as! PopularMoviesTblVwCell
        
        let object = PopularMovieDatas[indexPath.row]
        
        Cell.lblTittle.text! =  (object as AnyObject).value(forKey: "popularTitle") as! String
        
        Cell.lblPostOnDate.text! = "Released on:  " + "\((object as AnyObject).value(forKey: "popularPoston") as! String)"
        
        Cell.lblRate.text! = "Rating:  " + "\(String((object as AnyObject).value(forKey: "popularRating") as! Float))"
        Cell.lblOverview.text! = (object as AnyObject).value(forKey: "popularOverview") as! String
        


        if let postImg = (object as AnyObject).value(forKey: "popularImg")  {
            Cell.imgMovie.sd_setShowActivityIndicatorView(true)
            Cell.imgMovie.sd_setIndicatorStyle(.medium)
            
            
            //"https://image.tmdb.org/t/p" + "\(postImg)"
            Cell.imgMovie.sd_setImage(with: URL(string:  "https://picsum.photos/536/354", relativeTo: nil))
           
            print("https://image.tmdb.org/t/p" + "\(postImg)")
            
        }else {
            Cell.imgMovie.image = UIImage(named: "samplePoster")
            
        }
        
        Cell.lblOverview.tag = indexPath.row
        
        if self.selectIndex == indexPath.row {
            
            Cell.lblOverview.numberOfLines = 0
            
        }else {
            Cell.lblOverview.numberOfLines = 2
        }

        
        return Cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.selectIndex = indexPath.row
        
        self.PopularMovieTblVW.reloadRows(at: [indexPath], with: .none)
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            print("done")
        

        let VC = self.storyboard?.instantiateViewController(withIdentifier: "MovieDetailsVC") as! MovieDetailsVC
        VC.Index = indexPath.row
        
        VC.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        VC.navigationController?.modalPresentationStyle =
          UIModalPresentationStyle.fullScreen
            self.present(VC, animated: true, completion: nil)
        })
        
        
    }
    

    //MARK:- API Connection....
    func GetTrendingMovies()
    {
    
        let url : String = "https://api.themoviedb.org/3/trending/all/day?api_key=7e718bbe884ff492360be457092aa3fb"
         
        LoadingView.shared.showOverlay(view: self.view)
           Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
               .responseJSON { response in
                   switch response.result{
                       case .success(let json):
                           print(json)
                        
                        let jonDict = json as! NSDictionary
                        let JsonArry = jonDict["results"] as? NSArray
                           DispatchQueue.main.async {
                            
                            GetTrendingMoviesList(arr: JsonArry!)
                            self.GetPopularMovies()
                           }
                   case .failure( _):
                    LoadingView.shared.hideOverlayView()
                        self.displayAlertMaessage(userMessage : "Please check your network connection!")
                       }
               }
        
       
    }
    
    func GetPopularMovies()
    {
    
        let url : String = "https://api.themoviedb.org/3/movie/popular?api_key=7e718bbe884ff492360be457092aa3fb&language=en-US&page=1"
      
           Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
               .responseJSON { response in
                   switch response.result{
                       case .success(let json):
                           print(json)
                        
                        let jonDict = json as! NSDictionary
                        let JsonArry = jonDict["results"] as? NSArray
                           DispatchQueue.main.async {
                            
                            GetPopularMoviesList(arr: JsonArry!)
                            fetchingDatas()
                            LoadingView.shared.hideOverlayView()

                            self.TrendingMovieCollVW.reloadData()
                            self.PopularMovieTblVW.reloadData()
                           }
                       case .failure(let error):
                           print(error)
                        LoadingView.shared.hideOverlayView()

                       }
               }
    }
    
    
    
    
   
    
}



