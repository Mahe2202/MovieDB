//
//  MovieDetailsVC.swift
//  MovieDB
//
//  Created by Mahendran on 01/05/21.
//  Copyright © 2021 mahendran. All rights reserved.
//

import UIKit
import SDWebImage

class MovieDetailsVC: UIViewController {
    
    
    
    @IBOutlet weak var lblTittle: UILabel!
    
    @IBOutlet weak var lblPostOnDate: UILabel!
    
    @IBOutlet weak var lblOverview: UILabel!
    
    @IBOutlet weak var lblRate: UILabel!
    
    @IBOutlet weak var imgMovie: UIImageView!
    
    

    var Index : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        let object = PopularMovieDatas[Index!]
        
        self.lblTittle.text! =  (object as AnyObject).value(forKey: "popularTitle") as! String
        
        self.lblPostOnDate.text! = "Released on:  " + "\((object as AnyObject).value(forKey: "popularPoston") as! String)"
        
        self.lblRate.text! = "Rating:  " + "\(String((object as AnyObject).value(forKey: "popularRating") as! Float))"
        self.lblOverview.text! = (object as AnyObject).value(forKey: "popularOverview") as! String
        
        if (object as AnyObject).value(forKey: "popularImg") != nil  {
        self.imgMovie.sd_setShowActivityIndicatorView(true)
        self.imgMovie.sd_setIndicatorStyle(.medium)
        
        self.imgMovie.sd_setImage(with: URL(string:  "https://picsum.photos/536/354", relativeTo: nil))
        }
        
    }
    
    
    @IBAction func onBtnClose(sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }

}
