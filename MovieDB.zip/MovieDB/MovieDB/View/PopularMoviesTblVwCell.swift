//
//  PopularMoviesTblVwCell.swift
//  MovieDB
//
//  Created by Mahendran on 01/05/21.
//  Copyright © 2021 mahendran. All rights reserved.
//

import UIKit

class PopularMoviesTblVwCell: UITableViewCell {
    
    
    @IBOutlet weak var lblTittle: UILabel!
    
    @IBOutlet weak var lblPostOnDate: UILabel!
    
    @IBOutlet weak var lblOverview: UILabel!
    
    @IBOutlet weak var lblRate: UILabel!
    
    @IBOutlet weak var imgMovie: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
