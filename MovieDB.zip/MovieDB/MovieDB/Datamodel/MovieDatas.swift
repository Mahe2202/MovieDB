//
//  MoviewDB.swift
//  MoviewDB
//
//  Created by Mahendran on 01/05/21.
//  Copyright © 2021 mahendran. All rights reserved.
//

import Foundation
import UIKit
import CoreData

var TrendingMovieDatas = NSMutableArray()
var PopularMovieDatas = NSMutableArray()

// MARK: - Core Data stack


var persistentContainer: NSPersistentContainer = {
        
    /*
     The persistent container for the application. This implementation
     creates and returns a container, having loaded the store for the
     application to it. This property is optional since there are legitimate
     error conditions that could cause the creation of the store to fail.
     */
    let container = NSPersistentContainer(name: "MovieDB")
    container.loadPersistentStores(completionHandler: { (storeDescription, error) in
        if let error = error as NSError? {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            
            /*
             Typical reasons for an error here include:
             * The parent directory does not exist, cannot be created, or disallows writing.
             * The persistent store is not accessible, due to permissions or data protection when the device is locked.
             * The device is out of space.
             * The store could not be migrated to the current model version.
             Check the error message to determine what the actual problem was.
             */
            fatalError("Unresolved error \(error), \(error.userInfo)")
        }
    })
    return container
}()





// MARK: - Core Data Saving support

func saveContext () {
    let context = persistentContainer.viewContext
    print(context)
    //if context.hasChanges {
    do {
        try context.save()
        
        print("SAVED")
    } catch {
        // Replace this implementation with code to handle the error appropriately.
        // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        let nserror = error as NSError
        fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
    }
   // }
}




func GetTrendingMoviesList(arr: NSArray)

{
    
    TrendingMovieDatas.removeAllObjects()
    
    for arrData in arr
    {
        
        let dictData = arrData as! NSDictionary
        
        let conte = persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "TrendingMovies" , in: conte)!
        let theUser =  NSManagedObject(entity: entity, insertInto: conte)

        theUser.setValue(dictData["title"] as? String ?? "", forKey: "trendTitle")
        theUser.setValue(dictData["overview"] as? String ?? "", forKey: "trendOverview")
        theUser.setValue(dictData["release_date"] as? String ?? "", forKey: "trendPoston")
        theUser.setValue(dictData["vote_average"] as? Float ?? 0.0, forKey: "trendRating")
        theUser.setValue(String(dictData["id"] as? Int ?? 001), forKey: "trendId")
        theUser.setValue(dictData["backdrop_path"] as? String, forKey: "trendImg")
        
        do {
                   try conte.save()
                   print(conte)
           
                   print("Data Saved")
                   
                  
               }
               catch {
                   print("error")
                   
               }
        
        
        
    }
    
}
    
    
    func GetPopularMoviesList(arr: NSArray)

    {
        
        PopularMovieDatas.removeAllObjects()
        
        for arrData in arr
        {
            
            let dictData = arrData as! NSDictionary
            
            let conte = persistentContainer.viewContext
            let entity = NSEntityDescription.entity(forEntityName: "PopularMovies" , in: conte)!
            let theUser =  NSManagedObject(entity: entity, insertInto: conte)

            theUser.setValue(dictData["title"] as? String ?? "", forKey: "popularTitle")
            theUser.setValue(dictData["overview"] as? String ?? "", forKey: "popularOverview")
            theUser.setValue(dictData["release_date"] as? String ?? "", forKey: "popularPoston")
            theUser.setValue(dictData["vote_average"] as? Float ?? 0.0, forKey: "popularRating")
            theUser.setValue(String(dictData["id"] as? Int ?? 001), forKey: "popularId")
            theUser.setValue(dictData["backdrop_path"] as? String, forKey: "popularImg")
            
            do {
                       try conte.save()
                       print(conte)
               
                       print("Data Saved")
                       
                      
                   }
                   catch {
                       print("error")
                       
                   }
            
            
        }
    
}



        

// MARK:- FETCH DATASS......
func fetchingDatas()
{
  
    let douplicateTrendMovieArr = NSMutableArray()
    douplicateTrendMovieArr.removeAllObjects()
    
    let douplicatePopularMovieArr = NSMutableArray()
    douplicatePopularMovieArr.removeAllObjects()
    
    let conteTrendMovie = persistentContainer.viewContext
    let DataTableTrends = NSFetchRequest<NSFetchRequestResult>(entityName: "TrendingMovies")
    
    print(DataTableTrends)
    
    let contePopularMovie = persistentContainer.viewContext
    let DataTablePopular = NSFetchRequest<NSFetchRequestResult>(entityName: "PopularMovies")
    
    print(DataTablePopular)
    do {
        let dataTrend =  (try contePopularMovie.fetch(TrendingMovies.fetchRequest())) as [TrendingMovies]
        
        douplicateTrendMovieArr.addObjects(from: dataTrend as [Any])
        
        let dataPopular =  (try conteTrendMovie.fetch(PopularMovies.fetchRequest())) as [PopularMovies]
        
        douplicatePopularMovieArr.addObjects(from: dataPopular as [Any])
        
        noDuplicatesTrends(arrayOfDicts: douplicateTrendMovieArr)
        
        noDuplicatesPopular(arrayOfDicts: douplicatePopularMovieArr)
         
    }catch {
        
    }

    
}


func noDuplicatesTrends(arrayOfDicts: NSMutableArray) {

       var usedNames = [String]()
       for i in 0..<arrayOfDicts.count {

           let Time = arrayOfDicts[i]
           if let name = (Time as AnyObject).value(forKey: "trendId") as? String, !usedNames.contains(name) {
            TrendingMovieDatas.add(Time)
               usedNames.append(name)
           }
       }

   }


func noDuplicatesPopular(arrayOfDicts: NSMutableArray) {

       var usedNames = [String]()
       for i in 0..<arrayOfDicts.count {

           let Time = arrayOfDicts[i]
           if let name = (Time as AnyObject).value(forKey: "popularId") as? String, !usedNames.contains(name) {
            PopularMovieDatas.add(Time)
               usedNames.append(name)
           }
       }

   }





