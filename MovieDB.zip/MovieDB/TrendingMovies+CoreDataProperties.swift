//
//  TrendingMovies+CoreDataProperties.swift
//  MovieDB
//
//  Created by Mahendran on 01/05/21.
//  Copyright © 2021 mahendran. All rights reserved.
//
//

import Foundation
import CoreData


extension TrendingMovies {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TrendingMovies> {
        return NSFetchRequest<TrendingMovies>(entityName: "TrendingMovies")
    }

    @NSManaged public var trendImg: String?
    @NSManaged public var trendPoston: String?
    @NSManaged public var trendRating: Float
    @NSManaged public var trendTitle: String?
    @NSManaged public var trendId: String?
    @NSManaged public var trendOverview: String?

}

extension TrendingMovies : Identifiable {

}
