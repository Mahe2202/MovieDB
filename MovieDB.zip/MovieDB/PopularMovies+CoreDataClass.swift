//
//  PopularMovies+CoreDataClass.swift
//  MovieDB
//
//  Created by Mahendran on 01/05/21.
//  Copyright © 2021 mahendran. All rights reserved.
//
//

import Foundation
import CoreData

@objc(PopularMovies)
public class PopularMovies: NSManagedObject {

}
